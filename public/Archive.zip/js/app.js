$("#collapseOne").collapse();
$("#collapseTwo").collapse();
$("#collapseThree").collapse();
